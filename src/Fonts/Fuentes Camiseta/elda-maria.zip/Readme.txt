
The Elda Maria calligraphic font is free to use and its modification is forbidden.
Author's contact: darly.ospina@udea.edu.co
-Medellin, Colombia-