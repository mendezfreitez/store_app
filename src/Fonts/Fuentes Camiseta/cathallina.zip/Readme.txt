note:

-FONT LICENSE-

This font is 100% free and can be used for commercial purposes

however,
We will be very happy if you want to buy us a cup of coffee :D here:
https://www.paypal.com/paypalme2/panjiriz

we also have several paid fonts which you can see here:
https://graphicriver.net/user/under21studio/portfolio


visit our website:
https://under21.site (under consturction)
